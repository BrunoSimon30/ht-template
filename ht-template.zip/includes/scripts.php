<!-- Scripts -->
<script src="assets/js/vendor/bootstrap.bundle.min.js">
    </script>
    <script src="assets/js/vendor/jquery.min.js"></script>
    <script src="assets/js/vendor/swiper-bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/swiper-script.js"></script>
    <script src="assets/js/submit-form.js"></script>
    <script src="assets/js/vendor/isotope.pkgd.min.js"></script>
    <script src="assets/js/video_embedded.js"></script>
    <script src="https://kit.fontawesome.com/a6df7668b8.js" crossorigin="anonymous"></script>
    <script src="assets/js/vendor/fslightbox.js"></script>
	
    <script
        src="https://cdn.jsdelivr.net/gh/shishirraven/animate-on-scroll@v1.0/oyethemes_onscroll_animation.js"></script>
		<script src="https://unpkg.com/lenis@1.3.17/dist/lenis.min.js"></script> 
		<script src="assets/js/our.js"></script>