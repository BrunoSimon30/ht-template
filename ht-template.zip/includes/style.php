 

<link rel="icon" href="assets/image/icon.png">
<link rel="stylesheet" href="assets/css/our.css" />
<link rel="stylesheet" href="assets/css/style.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/shishirraven/animate-on-scroll@v1.2/animation_utility.css" />
<link rel="stylesheet" href="https://unpkg.com/lenis@1.3.17/dist/lenis.css">